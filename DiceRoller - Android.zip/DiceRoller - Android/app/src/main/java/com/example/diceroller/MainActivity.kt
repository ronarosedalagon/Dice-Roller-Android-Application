package com.example.diceroller

import android.animation.ObjectAnimator
import android.os.Bundle
import android.os.Handler
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rollButton: Button = findViewById(R.id.button)
        rollButton.setOnClickListener {
            rollDice()
        }
    }
    private fun rollDice(){
        val dice=Dice(6)
        val diceRoll = dice.roll()

        val diceImage: ImageView = findViewById(R.id.imageView)

        val drawableResource = when (diceRoll){
            1 -> R.drawable.dice_1
            2 -> R.drawable.dice_2
            3 -> R.drawable.dice_3
            4 -> R.drawable.dice_4
            5 -> R.drawable.dice_5
            else -> R.drawable.dice_6
        }

        diceImage.setImageResource(drawableResource)

        diceImage.contentDescription = diceRoll.toString()

        //Animation effect when rolling the dice
        val rotate = ObjectAnimator.ofFloat(
            diceImage, "rotation", 0f,20f,0f,-20f,0f
        )
        rotate.repeatCount = 5
        rotate.duration = 80

        rotate.start()

        //Adding delay on showing text
        val handler = Handler()
        handler.postDelayed({
            //Adding text on the interface
            val txtView: TextView = findViewById(R.id.textView2)
            val textView = when (diceRoll){
                1 -> txtView.setText("1")
                2 -> txtView.setText("2")
                3 -> txtView.setText("3")
                4 -> txtView.setText("4")
                5 -> txtView.setText("5")
                else -> txtView.setText("6")
            }
        }, 600)
    }
}
class Dice(val numSlides: Int){
    fun roll():Int {
        return (1..numSlides).random()
    }
}